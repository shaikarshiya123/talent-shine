package validation;

public class Validation {
	public static void validate() {
		
	}
}
