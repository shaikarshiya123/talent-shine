package Val;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Vall
 */
//@WebServlet("/Vall")
public class Vall extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Vall() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		
		
		String name=request.getParameter("name");
		String pass=request.getParameter("pass");
		//String emai=request.getParameter("email");
		String passpatt=pass.trim();
		String Name=name.trim();
		int PassSize=passpatt.length();
		if(PassSize<8) {
			pw.println("<!DOCTYPE html>");
			pw.println("<html>");
			pw.println("<head>");
			pw.println("<style>body{\r\n"
					+"border:solid black;\r\n"
					+ "width:350px;\r\n"
					+ "margin-left:500px;\r\n"
					+ "margin-top:100px;\r\n"
					+ "height:70px;\r\n"
					+ "font-size:20px;\r\n"
					+ "padding:10px;\r\n"
					+ "color:red;\r\n"
					+"button{width:65px;\r\n"
					+ "height:30px;\r\n"
					+ "font-size:15px;\r\n"
					+"button{\r\n"
					+"margin-left:40px;\r\n"
					+"}");
			pw.println("</style>");
			pw.println("</head>");
			pw.println("<body>");
			pw.println("<b>password should be morethan 8 characters..!</b><br>");
			//pw.println("<form action=\"login.html\" method=\"get\">");
			pw.println("<a href=\"login.html\" id=\"a\"><button>cancel</button></a>");
			pw.println("</form>");
			pw.println("</body>");
			pw.println("</html>");
		}
		else if(Name.length()==0) {
			pw.println("<!DOCTYPE html>");
			pw.println("<html>");
			pw.println("<head>");
			pw.println("<style>body{\r\n"
					+"border:solid black 1px;\r\n"
					+ "width:350px;\r\n"
					+ "margin-left:400px;\r\n"
					+ "margin-top:80px;\r\n"
					+ "height:50px;\r\n"
					+ "font-size:20px;\r\n"
					+ "padding:10px;\r\n"
					+ "color:red;\r\n"
					+"button{width:65px;\r\n"
					+ "height:30px;\r\n"
					+ "font-size:15px;\r\n"
					+ "text:center;\r\n"
					+ "margin-left:40px;\r\n"
					+ "}");
			pw.println("</style>");
			pw.println("</head>");
			pw.println("<body>");

			pw.println("<b>name is empty!</b><br>");
			pw.println("<a href=\"login.html\"><button>cancel</button></a>");
			pw.println("</form>");
			pw.println("</body>");
			pw.println("</html>");
			//pw.println("name is empty");
		}
		else {
			//pw.println("<a href=\"district.html\"></a>");
			response.sendRedirect("district.html");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	

}
