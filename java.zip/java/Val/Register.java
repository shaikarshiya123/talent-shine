package Val;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/register")
public class Register extends HttpServlet {
	
	private final static String query="insert into student(name,course,email,mobile) values(?,?,?,?)";
	@Override
	protected void doGet(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=rs.getWriter();
		rs.setContentType("text/html");
		String name=rq.getParameter("textnames");
		String course=rq.getParameter("Course");
		String email=rq.getParameter("emailid");
		String mobile=rq.getParameter("mobileno");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		try(Connection con=DriverManager.getConnection("jdbc:mysql:///registration","root","habeeba");PreparedStatement ps=con.prepareStatement(query);) {
			ps.setString(1, name);
			ps.setString(2, course);
			ps.setString(3, email);
			ps.setString(4, mobile);
			int count=ps.executeUpdate();
			if(count==1) {
				pw.println("<h2>Record Registered Successfully</h2>");
			}else {
				pw.println("<h2>Record Not Registered</h2>");
			}
		}
		catch(SQLException se) {
			pw.println(se.getMessage());
			se.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
