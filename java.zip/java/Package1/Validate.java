package Package1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Validate
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   private final static String query="insert into user(name,password) values(?,?)";
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		String name=request.getParameter("name");
		String pass=request.getParameter("pass");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		try(Connection con=DriverManager.getConnection("jdbc:mysql:///login","root","habeeba");
				PreparedStatement ps=con.prepareStatement(query);){
			ps.setString(1, name);
			ps.setString(2, pass);
			int count=ps.executeUpdate();
			if(count==1) {
				pw.println("Record stored");
			}
			else {
				pw.println("Record not stored");
			}
				
		}
		catch(SQLException e) {
			pw=println("<h2>"+e.getMessage()+"</h2>");
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	private PrintWriter println(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
